export declare class HealthConnectError extends Error {
    constructor(message: string, method: string);
}
//# sourceMappingURL=errors.d.ts.map